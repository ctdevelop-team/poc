/*eslint no-console: 0, no-unused-vars: 0*/
"use strict";
var https = require("https");
var request = require("@sap/xsjs/node_modules/request");
var xsjs  = require("@sap/xsjs");
var xsenv = require("@sap/xsenv");
var port  = process.env.PORT || 3000;
var express = require("express");
var globalBody;
var app = express();
var configData = require("./config.json");
var options, data, token;

// setting Response
app.set('json spaces', 1400);
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.setHeader("Access-Control-Allow-Headers",
    "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, access-control-allow-origin, cache-control"
  );
  next();
});

// get Weather Data
var weather_options = {
  'method': 'GET',
  'url': configData.weather_api,
  'headers': {
  }
};
request(weather_options, function (error, response) { 
  if (error) throw new Error(error);
  console.log(response.body);
  globalBody = response.body;
});

// send proof history as response
app.get('/GET_WEATHER_DATA', function (req, res, next) {
  res.json(globalBody);
});

app.get('/', (req, res) => {
  res.send('Hi!')
})

options = {
	anonymous : true, // remove to authenticate calls
	auditLog : { logToConsole: true } // change to auditlog service for productive scenarios
	//redirectUrl : "/index.xsjs"
};
// configure HANA
try {
	options = Object.assign(options, xsenv.getServices({ hana: {tag: "hana"} }));
} catch (err) {
	console.log("[WARN]", err.message);
}

// configure UAA
try {
	options = Object.assign(options, xsenv.getServices({ uaa: {tag: "xsuaa"} }));
} catch (err) {
	console.log("[WARN]", err.message);
}
// start server
app.listen(process.env.PORT, () => console.log('Server ready'))
// start server
// xsjs(options).listen(port);
// console.log("Server listening on port %d", port);