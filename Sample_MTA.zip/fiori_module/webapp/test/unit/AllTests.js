sap.ui.define([
	"fiori_module/fiori_module/test/unit/controller/Main.controller"
], function () {
	"use strict";
});