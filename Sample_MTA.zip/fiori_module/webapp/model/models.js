sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
				var oModel = new JSONModel(Device);
				oModel.setDefaultBindingMode("OneWay");
				return oModel;
			},
			//UI5 Configuration model
		createAppConfigModel: function () {
			var appData = {
				"protocol": "https://",
				"apiUrl": "tcdf7yrzvrxx2ehne-mta-node-module.cfapps.eu10.hana.ondemand.com"
			};
			var oModel = new JSONModel(appData);
			return oModel;
		}
	};
});