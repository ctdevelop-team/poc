sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller,MessageBox) {
	"use strict";

	return Controller.extend("fiori_module.fiori_module.controller.Main", {
		onInit: function () {
			this.getWeather();
		},

		getWeather: function () {
			var that = this;
			var oModelAppConfig = that.getOwnerComponent().getModel("AppConfig");
			var sHTTPS = oModelAppConfig.getProperty("/protocol");
			var uri = oModelAppConfig.getProperty("/apiUrl");
			var sUrl = sHTTPS + uri + "/GET_WEATHER_DATA";
			var settings = {
				"async": true,
				"crossDomain": true,
				"url": sUrl,
				"method": "GET",
				"headers": {
					"cache-control": "no-cache",
					"Access-Control-Allow-Origin": "*",
					"Access-Control-Allow-Headers": "*"
				}
			};
			$.ajax(settings).done(function (response) {
				// that.getView().byId("idOutput").setText(response);
				var results = [];
				response = JSON.parse(response);
				response.list.forEach(function (temp) {
					if (temp !== undefined && temp !== "") {
						results.push({
							"forecast": temp.weather[0].description,
							"min_temp": temp.main.temp_min,
							"max_temp": temp.main.temp_max,
							"humidity": temp.main.humidity,
							"wind_speed": temp.wind.speed,
							"date": temp.dt_txt
						});
					}
				});
				var jsonModel = new sap.ui.model.json.JSONModel({
					results: results
				});
				that.getView().byId("idTable").setModel(jsonModel, "weathereData");
				MessageBox.success("Weather Data Loaded Successfully!");
			});

		}
	});
});